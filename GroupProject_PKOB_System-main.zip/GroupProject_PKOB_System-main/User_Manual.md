## User Manual
User Manual For Website
 
(LOGIN)  
1. Firstly, Tok Penghulu should click the log masuk button to login there account
![LOGIN](/images/loginpanel.png)
   
2. The system will display a login form and the Tok Penghulu can enter the user id and password. After done enter the user id and password can click log masuk button to login
![LOGIN](/images/logininput.png)
  
3. After succesfully login the account, the system will display the HomePage of our system.
![LOGIN](/images/homepage.png)
  
(DAFTAR MANGSA) (MANAGE MANGSA)
1. Firstly, Tok Penghulu should click the daftar magsa button.
![LOGIN](/images/clickdaftar.png)
 
2. The system will display a daftar form and Tok Penghulu can enter the detail of mangsa and click daftar button.
![LOGIN](/images/inputdaftar.png)
 
3. After succesfully daftar the mangsa, the system will display the Mangsa Didaftarkan page. Tok Penghulu able to terima, kemaskini dan padam the mangsa in this page.
![LOGIN](/images/mangsadidaftar.png)
 
4. If Tok Penghulu click diterima button, the system will display the mangsa detail and Tok Penghulu can click the terima button to terima the mangsa.
![LOGIN](/images/terima.png)
 
5. After Tok Penghulu click the terima button, the system will pop up a question and Tok Penghulu can click ok or cancel.
![LOGIN](/images/acceptterima.png)
 
6. After click the ok button, the system will add the mangsa to terima list.
![LOGIN](/images/sucessterima.png)
 
7. If Tok Penghulu click the kemaskini button, the system will display mangsa detail and Tok Penghulu can enter the new detail and click the kemaskini button to edit the mangsa detail.
![LOGIN](/images/kemaskini.png)
 
8. If Tok Penghulu click the padam button, the system will pop up a question message and Tok Penghulu can click ok or cancel.
![LOGIN](/images/padam.png)
 
(MANAGE PENDAFTARAN)
 
1. Firstly, Tok Penghulu should click the pendaftaran button and the system will display the pendafataran panel.
![LOGIN](/images/pendaftaran.png)
 
2. If Tok Penghulu click the terima button, the system will display the mangsa detail and Tok Penghulu can click rhe terima button.
![LOGIN](/images/daftarterima.png)
 
3. After click the terima button, the system will pop up a question message and Tok Penghulu can click ok or cancel.
![LOGIN](/images/acceptterimadaftar.png)
 
4. If Tok Penghulu click the tolak button, the system will display the mangsa detail and Tok Penghulu can click the tolak button.
![LOGIN](/images/tolakdaftar.png)
 
5. After Tok Penghulu click the tolak button, the system will display a question message and Tok Penghulu can click ok or cancel.
![LOGIN](/images/accepttolak.png)
 
6. If Tok Penghulu click the Padam button, the system will pop up a question messageand Tok Penghulu can clikc ok or cancel. After that the system will pop up succesfully message.
![LOGIN](/images/padampadam.png)
 
(Manage Tolak)

1. Firstly, Tok Penghulu should click the pendaftaran ditolak button and the system will display the pendaftaran ditolak page. Tok Penghulu can click the Padam button
![LOGIN](/images/padamtolak.png)
 
2. After that the system will pop up succesfully message.
![LOGIN](/images/sucesspadamtolak.png)
 
 </br></br>
 User Manual For Telegram Bot
 
1. This is the PKOB HelloWorld BOT. The user can click the start button to start the telegram bot.
<p><img src="images/tbot.jpeg" /></p>
   
2.After clicking the start button, the bot will respond and display the commands and descriptions about this bot. There have 2 keyboard button which are semak status and tujuan pkob for user to click.
<p><img src="images/telegramBot2.jpeg" /></p>
  
3.When the user uses the /tujuan pkob command, the bot will respond and display the bot's functions. 
<p><img src="images/telegramBot3.jpeg" /></p>
  
4.When the user uses the /semak status command, the bot will respond and ask the user to enter their data in the requested format, namely the Nombor Kad Pengenalan and the Nombor Telefon.
<p><img src="images/telegramBot4.jpeg" /></p>
 
If the user input the information in the requested format, but the entered data is not searched in the database, the bot will respond and display maklumat tidak didapati. Users can go to website link to apply their data first.
If the user enters the information in the requested format and finds the entered data in the database, the bot will respond and display their data. The information of victim will be display and user can check their name, age, IC number, phone number, and status. Status includes sedang diproses, diterima, ditolak.
If the information entered by the user does not conform to the format, the bot will respond and display tidak faham mesej anda! Please follow the format or type /start command to activate again the bot.
<p><img src="images/telegramBot5.jpeg" /></p>
<p><img src="images/telegramBot6.jpeg" /></p>
<p><img src="images/telegramBot7.jpeg" /></p>
<p><img src="images/telegramBot8.jpeg" /></p>

